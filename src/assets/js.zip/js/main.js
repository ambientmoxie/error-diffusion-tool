import "../scss/style.scss";
import p5 from "p5";
import floydSteinbergDithering from "./modules/filter";
import { Pane } from "tweakpane";

// Setup variables
const size = 700;
const border = 20;
let img;
let dropImg;
let seedImage;

// Drop variables
let ratio;
let newImageDropped;
let posX, posY, dropWidth, dropHeight;

// Graphic containers
let main, buffer;

// Handle the image drop placement and size
function imageDropRatio(img) {
  if (img.width < img.height) {
    ratio = img.width / img.height;
    dropWidth = main.width * ratio;
    dropHeight = main.height;
    posX = (main.width - dropWidth) / 2;
    posY = 0;
  } else {
    ratio = img.height / img.width;
    dropWidth = main.width;
    dropHeight = main.height * ratio;
    posX = 0;
    posY = (main.height - dropHeight) / 2;
  }
}

const tool = (p) => {
  p.setup = () => {
    // Setup basic canvas
    let canvas = p.createCanvas(size, size);
    canvas.id("dithered");
    p.background(255);

    // Drop file handler
    canvas.drop((file) => {
      dropImg = p.createImg(file.data, "").hide(); // https://p5js.org/reference/#/p5.Element/drop
      newImageDropped = true;
    });

    // Setup mainraphic
    main = p.createGraphics(size, size);
    // main.background(255, 0, 0);
    main.noSmooth();
  };

  function processAndDisplay() {
    if (seedImage) {
      // Clone the image
      img = seedImage.get();
      // Populate variables depending on the orientation
      imageDropRatio(img);
      // Create new buffer at orignal image size but dont display it
      buffer = p.createGraphics(img.width, img.height);
      // Handle the image resizing
      img.resize(img.width * PARAMS.factor, img.height * PARAMS.factor);
      // Refine the pixel
      //! NO NEED OF THIS AFTER TRANSFORMATION !\\
      buffer.noSmooth();
      // Colored version or not
      PARAMS.isBlackAndWhite ? img.filter(p.GRAY) : "";
      // Apply floyd steinberg filter
      floydSteinbergDithering(p, img);
      // Draw image on the buffer;
      //! START OF PROBLEMATIC PART !\\
      //! Instead of streatching the resized img, redraw each pixel.
      buffer.image(
        img,
        0,
        0,
        img.width / PARAMS.factor,
        img.height / PARAMS.factor
      );
      //! END OF PROBLEMATIC PART !\\
      // Display image
      main.image(img, posX, posY, dropWidth, dropHeight);
      // Download the buffer
      // p.save(buffer, "buffer_output.png");
      // p.save(buffer, "buffer_output.png");
    }
  }

  // Tweakpane
  const PARAMS = {
    isBlackAndWhite: false,
    factor: 0.3, // between 1 and 10.
  };

  const pane = new Pane();

  pane
    .addBinding(PARAMS, "factor", {
      min: 0.1,
      max: 1,
      step: 0.1,
      label: "Scaling",
    })
    .on("change", () => {
      console.log(PARAMS.factor);
      processAndDisplay();
    });

  pane
    .addBinding(PARAMS, "isBlackAndWhite", {
      label: "Color",
    })
    .on("change", () => {
      processAndDisplay();
    });

  pane
    .addButton({
      title: "Download",
    })
    .on("click", () => {
      p.save(buffer, "buffer_output.png");
    });

  p.draw = () => {
    // If new image drop
    if (newImageDropped) {
      // Turn var to false avoid new loop
      newImageDropped = false;

      p.loadImage(dropImg.elt.src, (loadedImage) => {
        // Remove previous image
        main.background(255);
        // Load the image
        // img = loadedImage;
        seedImage = loadedImage; // Store the original image
        processAndDisplay();
      });
    }

    // Redraw mainraphic every frame
    p.image(main, border / 2, border / 2, size - border, size - border);
  };
};

export default tool;

new p5(tool);
